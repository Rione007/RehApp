package com.dam.rehapp.data.model

data class Instruccion(
    val orden: Int,
    val descripcion: String
)
