package com.dam.rehapp.data.model

data class ProgresoNivel(
    val nivelId: Int,
    var progreso: Int,
    var tiempoTotal: Long
)
