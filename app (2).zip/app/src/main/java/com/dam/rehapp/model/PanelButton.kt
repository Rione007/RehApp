package com.dam.rehapp.model

import android.widget.LinearLayout
import androidx.fragment.app.Fragment

data class PanelButton (
    val container: LinearLayout,
    val fragment: Fragment
)